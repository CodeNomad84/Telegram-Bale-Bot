## tools/build_excels.py

"""Generate data/*.xlsx from "ربات اجرایی.docx".

Run with:  python -m tools.build_excels
"""

import html
import re
import shutil
import sys
import zipfile
from pathlib import Path

from openpyxl import Workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from config import DOCX_PATH

import html
import re
import shutil
import sys
import zipfile
from pathlib import Path

from openpyxl import Workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from config import each question, in document order.
CODE_MAP = [
    [4, 2, 5, 1, 3],  # Q1 - spoiled food, parent reaction
    [1, 5, 3, 2, 4],  # Q2 - child refuses the party and asks to hide it
    [3, 1, 4, 5, 2],  # Q3 - choosing a high-school field against the parent
    [5, 2, 4, 1, 3],  # Q4 - choosing playground equipment
    [2, 4, 5, 1, 3],  # Q5 - a 12-year-old cooking
]
OPTION_LABELS = ["الف", "ب", "ج", "د", "ه"]

# code -> (title, nickname, image filename)
TYPES = {
    1: ("والد پشتیبان و حمایتگر", "برج مراقبت", "borj_moraghebat.jان و حمایتگر", "برج مراقبت", "borj_moraghebat.j کنترل", "دوربین مداربسته", "durbin_madarbaste.jpg"),
    4: ("آزادی و محبت افراطی و سروری بیش از اندازهٔ فرزند", "خودپرداز", "khodpardaz.jpg"),
    5: ("والد پرخاشگر", "پرتابگر دمپایی", "partabgar_dampayi.jpg"),
}

# product_key -> (name, url). Numeric product paths redirect on keraamat.ir.
PRODUCTS = {
    "single": ("دوره آموزشی تشکیل خانواده", "https://www.keraamat.ir/FProduct/81/"),
    "mother": ("دوره آموزشی تثبیت و تحکیم خانواده", "https://www.keraamat.ir/FProduct/82/"),
    "father": ("دوره آموزشی بهبود روابط خانوادگی", "https://www.keraamat.ir/FProduct/113/"),
    "girl": ("دوره جامع تربیت دخترانه", "https://www.keraamat.ir/FProduct/35/"),
    "boy": ("دوره جامع تربیت پسرانه", "https://www.keraamat.ir/FProduct/34/"),
    "both": ("دوره آموزشی تربیت جنسی و مدیریت عواطف", "https://www.keraamat.ir/FProduct/115/"),
}

# q_key, q_text, opt_text, role, gender, children, product_key
INTRO_ROWS = [
    ("marital", "وضعیت تاهل خودتونو انتخاب کنین.", "عزب می‌باشم (مجرد)", "", "", "", "single"),
    ("marital", "وضعیت تاهل خودتونو انتخاب کنین.", "مامان هستم", "mother", "female", "", "mother"),
    ("marital", "وضعیت تاهل خودتونو انتخاب کنین.", "بابا هستم", "father", "male", "", "father"),
    ("child_gender", "جنسیت فرزندتون چیه؟", "دختر قندعسل", "", "", "girl", "girl"),
    ("child_gender", "جنسیت فرزندتون چیه؟", "پسر کاکل‌به‌سر", "", "", "boy", "boy"),
    ("child_gender", "جنسیت فرزندتون چیه؟", "جنسمون جوره، دختر و پسر", "", "", "both", "both"),
]

QUESTION_HEAD = re.compile(r"^\s*(?:سؤال|سوال)?\s*([۰-۹0-9]+)\s*[).:\-–]")
OPTION_HEAD = re.compile(r"^\s*(الف|ب|ج|د|ه|هـ)\s*[).:\-–]\s*(.+)$")
FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")


def docx_paragraphs(path):
    """Read paragraph tex archive.read("word/document/document.xml (no extra dependency)."""
    with zipfile.ZipFile(path) as archive:
        xml = archive.read("word/document.xml").decode("utf-8")
    paragraphs = []
    for block in re.split(r"</w:p>", xml):
        text = "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", block, flags=re.S))
        text = html.unescape(re.sub(r"<[^>]+>", "", text)).replace("\u200f", "").strip()
        if text:
            paragraphs.append(text)
    return paragraphs


def extract_questions(paragraphs):
    """Group each question stem with its five options, in document order."""
    groups, current = [], None
    for line in paragraphs:
        option = OPTION_HEAD.match(line)
        if option and current is not None:
            current["options"].append(option.group(2).strip())
            continue
        # A numbered line, or any long line, starts a new question block.
        if QUESTION_HEAD.match(line) or len(line) > 40:
            if current and len(current["options"]) == 5:
                groups.append(current)
            current = {"text": QUESTION_HEAD.sub("", line).strip(), "options": []}
    if current and len(current["options"]) == 5:
        groups.append(current)
    # Drop anything that is actually an intro question.
    intro_texts = {row[2] for row in INTRO_ROWS}
    return [g for g in groups if not set(g["options"]) & intro_texts]


def write_sheet(path, header, rows):
    """Write one sheet, keeping a .bak copy of any existing file."""
    if path.exists():
        shutil.copyfile(path, path.with_suffix(path.suffix + ".bak"))
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.append(header)
    for row in rows:
        worksheet.append(list(row))
    for index, _ in enumerate
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.append(header)
    for row in rows:
        worksheet.append(list(row))
    for index, _ in enumerate(header, start=1):
        worksheet.column_dimensions[worksheet.cell(row=1, column=index).column_letter].width = 40
    workbook.save(path)
    print(f"O.exit(f"Document not found: {DOCX_PATH}")

    questions = extract_questions(docx_paragraphs(DOCX_PATH))
    if len(questions) < len(CODE_MAP):
        sys.exit(
            f"Only {len(questions)} five-option questions were extracted, "
            f"but {len(CODE_MAP)} are required. "
            "Check the document structure or fill the question texts in manually."
        )
    questions = questions[: len(CODE_MAP)]

    question_rows = []
    for q_index, (question, codes) in enumerate(zip(questions, CODE_MAP), start=1):
        for label, text, code in zip(OPTION_LABELS, question["options"], codes):
            question_rows.append((q_index, question["text"], label, text, code))

    write_sheet(
        QUESTIONS_FILE, ["q_index", "q_text", "opt_label", "opt_text", "code"], question_rows
    )
    write_sheet(
        INTRO_FILE,
        ["q_key", "q_text", "opt_text", "role", "gender", "children", "product_key"],
        INTRO_ROWS,
    )
    write_sheet(
        RESULT_TEXTS_FILE,
        ["code", "title", "nickname", "description"],
        [
            (code, title, nickname, f"{title} — «{nickname}»")
            for code, (title, nickname, _) in sorted(TYPES.items())
        ],
    )
    write_sheet(
        RESULT_IMAGES_FILE,
        ["code", "image"],
        [(code, image) for code, (_, _, image) in sorted(TYPES.items())],
    )
    write_sheet(
        PRODUCTS_FILE,
        ["product_key", "name", "url"],
        [(key, name, url) for key, (name, url) in PRODUCTS.items()],
    )
    print("\nReminder: the description column in RESULT_TEXTS.xlsx is still a stub; "
          "paste the full text for each personality type there.")


if __name__ == "__main__":
    main()