from balethon.objects import InlineKeyboard

from config import CHANNEL_LINK


def join_keyboard():
    return InlineKeyboard(
        [{"text": "عضویت در کانال 🔗", "url": CHANNEL_LINK}],
        [{"text": "بررسی عضویت ✅", "callback_data": "check_join"}],
    )


def username_keyboard():
    return InlineKeyboard(
        [{"text": "بدون آیدی ادامه بده ➡️", "callback_data": "username:skip"}],
    )


def options_keyboard(prefix, options):
    """هر گزینه در یک ردیف؛ callback_data = prefix:index"""
    rows = [
        [{"text": text, "callback_data": f"{prefix}:{index}"}]
        for index, text in enumerate(options)
    ]
    return InlineKeyboard(*rows)


def finish_keyboard(invite_link):
    return InlineKeyboard(
        [{"text": "📋 رونوشت از لینک معرفی", "copy_text": {"text": invite_link}}],
        [{"text": "شروع مجدد 🔄", "callback_data": "restart"}],
    )
