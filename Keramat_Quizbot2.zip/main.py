## main.py

"""Routing only: messages and callback queries are dispatched to handlers."""

import asyncio

from bot_instance import bot
from config import FALLBACK_TEXT, NOT_JOINED_TEXT
from database.db import ensure_user, get_user, init_db, register_invite, reset_quiz
from handlers.intro import handle_intro_answer
from handlers.membership import is_member
from handlers.quiz import handle_quiz_answer
from handlers.registration import (
    ask_username,
    handle_username_text,
    send_welcome_gate,
    skip_username,
)
from handlers.states import STATE_AWAIT_USERNAME, build_display_name

# Inviter ids held between /start and a confirmed channel membership.
PENDING_INVITER = {}


def parse_start_payload(text):
    """Extract the inviter id from "/start <user_id>", if present."""
    parts = (text or "").split(maxsplit=1)
    if len(parts) == 2 and parts[1].strip().isdigit():
        return int(parts[1].strip())
    return None


@bot.on_message()
async def on_message(message):
    if message.author is None:
        return
    user_id = message.author.id
    text = (message.text or "").strip()
    await ensure_user(user_id, build_display_name(message.author))

    if text.startswith("/start"):
        inviter_id = parse_start_payload(text)
        if inviter_id and inviter_id != user_id:
            PENDING_INVITER[user_id] = inviter_id
        await reset_quiz(user_id)
        await send_welcome_gate(user_id)
        return

    user = await get_user(user_id)
    if user and user["state"] == STATE_AWAIT_USERNAME:
        await handle_username_text(user_id, text)
        return

    # Any other free-text message: point the user back to the buttons.
    await botUSERNAME:
       await handle_username_text(user_id, text)
        return

    # Any other free-text message: point the user back to the buttons.
    await bot.send_message(user_id, text=FALLBACK_TEXT)


@bot.on_callback_query()
async def on_callback_query(callback_query):
    if callback_query.author is None:
        (user_id):
            await callback_query.answer(NOT_JOINED_TEXT, show_alert=True)
            return
        await callback_query.answer("عضویتت تایید شد ✅")
        inviter_id = PENDING_INVITER.pop(user_id, None)
        if inviter_id:
            await register_invite(inviter_id, user_id)
        await ask_username(user_id)
        return

    if data == "username:skip":
        await callback_query.answer("باشه، بدون آیدی ادامه می‌دهیم")
        await skip_username(user_id)
        return

    if data == "restart":
        await callback_query.answer("از نو شروع می‌کنیم 🔄")
        await reset_quiz(user_id)
        await send_welcome_gate(user_id)
        return

    if data.startswith("intro:") or data.startswith("quiz:"):
        try:
            kind, index, option_index = data.split(":")
            index, option_index = int(index), int(option_index)
        except ValueError:
            await callback_query.answer("دادهٔ نامعتبر")
            return
        handler = handle_intro_answer if kind == "intro" else handle_quiz_answer
        accepted = await handler(user_id, index, option_index)
        await callback_query.answer("ثبت شد ✅" if accepted else "این سؤال قبلاً پاسخ داده شده")
        return

    # Always answer, otherwise the client keeps showing a spinner.
    await callback_query.answer()


async def startup():
    await init_db()


if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(startup())
    bot.run()
