## handlers/quiz.py

"""The five scored questions."""

from bot_instance import bot
from data.content import QUESTIONS
from database.db import get_user, update_user
from handlers.states import STATE_QUIZ
from keyboards.builders import options_keyboard


async def start_quiz(user_id):
    await update_user(user_id, state=STATE_QUIZ, step=0, answers=[])
    await send_question(user_id, 0)


async def send_question(user_id, index):
    question = QUESTIONS[index]
    header = f"سؤال {index + 1} از {len(QUESTIONS)}\n\n"
    await bot.send_message(
        user_id,
        text=header + question["text"],
        reply_markup=options_keyboard(
            f"quiz:{index}",
            [f"{option['label']}) {option['text']}" for option in question["options"]],
        ),
    )


async def handle_quiz_answer(user_id, index, option_index):
    """Record one answer. Out-of-turn taps (old messages) are rejected."""
    user = await get_user(user_id)
    if user is None or index != user["step"]:
        return False
    options = QUESTIONS[index]["options"]
    if not 0 <= option_index < len(options):
        return False

    answers = list(user["answers"])
    answers.append(options[option_index]["code"])
    next_step = index + 1
    await update_user(user_id, answers=answers, step=next_step)

    if next_step < len(QUESTIONS):
        await send_question(user_id, next_step)
    else:
        from handlers.result import send_result  # lazy import to avoid a cycle

        await send_result(user_id)
    return True